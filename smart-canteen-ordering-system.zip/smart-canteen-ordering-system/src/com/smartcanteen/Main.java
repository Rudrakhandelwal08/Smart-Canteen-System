package com.smartcanteen;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        int port = 8091;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        CanteenService canteen = new CanteenService();
        Path publicFolder = Paths.get("public").toAbsolutePath().normalize();

        server.createContext("/api/menu", exchange -> {
            if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
                send(exchange, 405, "application/json", "{\"error\":\"Method not allowed\"}");
                return;
            }
            send(exchange, 200, "application/json; charset=UTF-8", canteen.menuAsJson());
        });

        server.createContext("/api/checkout", exchange -> {
            if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                send(exchange, 405, "application/json", "{\"error\":\"Use POST to place an order\"}");
                return;
            }
            try {
                String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                Map<String, String> fields = parseForm(body);
                String cart = fields.getOrDefault("cart", "");
                String customer = fields.getOrDefault("customer", "Guest").trim();
                if (customer.isEmpty()) customer = "Guest";
                OrderReceipt receipt = canteen.placeOrder(customer, cart);
                send(exchange, 200, "application/json; charset=UTF-8", receipt.toJson());
            } catch (CanteenException e) {
                send(exchange, 400, "application/json; charset=UTF-8", "{\"error\":\"" + jsonEscape(e.getMessage()) + "\"}");
            } catch (Exception e) {
                send(exchange, 500, "application/json; charset=UTF-8", "{\"error\":\"Something went wrong. Please try again.\"}");
            }
        });

        server.createContext("/", exchange -> serveStatic(exchange, publicFolder));
        server.setExecutor(null);
        server.start();
        System.out.println("Smart Canteen is running at http://localhost:" + port);
        System.out.println("Keep this terminal open while using the website. Press Ctrl+C to stop.");
    }

    private static void serveStatic(HttpExchange exchange, Path publicFolder) throws IOException {
        String requested = exchange.getRequestURI().getPath();
        if (requested.equals("/")) requested = "/index.html";
        Path file = publicFolder.resolve(requested.substring(1)).normalize();
        if (!file.startsWith(publicFolder) || !Files.isRegularFile(file)) {
            send(exchange, 404, "text/plain; charset=UTF-8", "Page not found");
            return;
        }
        String type = "text/plain; charset=UTF-8";
        String name = file.getFileName().toString();
        if (name.endsWith(".html")) type = "text/html; charset=UTF-8";
        else if (name.endsWith(".css")) type = "text/css; charset=UTF-8";
        else if (name.endsWith(".js")) type = "application/javascript; charset=UTF-8";
        byte[] content = Files.readAllBytes(file);
        exchange.getResponseHeaders().set("Content-Type", type);
        exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        exchange.sendResponseHeaders(200, content.length);
        try (OutputStream out = exchange.getResponseBody()) { out.write(content); }
    }

    private static Map<String, String> parseForm(String body) throws UnsupportedEncodingException {
        Map<String, String> fields = new HashMap<>();
        for (String pair : body.split("&")) {
            String[] parts = pair.split("=", 2);
            if (parts.length == 2) fields.put(URLDecoder.decode(parts[0], "UTF-8"), URLDecoder.decode(parts[1], "UTF-8"));
        }
        return fields;
    }

    private static void send(HttpExchange exchange, int status, String type, String message) throws IOException {
        byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", type);
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) { out.write(bytes); }
    }

    private static String jsonEscape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
    }
}

abstract class MenuItem {
    private final int id;
    private String name;
    private double price;
    private String category;

    public MenuItem() { this(0, "Unnamed item", 0.0, "Other"); }
    public MenuItem(int id, String name, double price, String category) {
        this.id = id; this.name = name; this.price = price; this.category = category;
    }
    public MenuItem(MenuItem other) { this(other.id, other.name, other.price, other.category); }
    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getCategory() { return category; }
    public void setName(String name) { if (name != null && !name.isBlank()) this.name = name; }
    public void setPrice(double price) { if (price >= 0) this.price = price; }
    public void setCategory(String category) { if (category != null && !category.isBlank()) this.category = category; }
    public abstract double calculatePrice(int quantity);
}

class FoodItem extends MenuItem {
    public FoodItem(int id, String name, double price, String category) { super(id, name, price, category); }
    public FoodItem(FoodItem other) { super(other); }
    @Override public double calculatePrice(int quantity) { return getPrice() * quantity; }
}

class DrinkItem extends MenuItem {
    public DrinkItem(int id, String name, double price, String category) { super(id, name, price, category); }
    @Override public double calculatePrice(int quantity) { return getPrice() * quantity; }
}

class OrderItem {
    private final MenuItem item;
    private int quantity;
    public OrderItem(MenuItem item, int quantity) { this.item = item; setQuantity(quantity); }
    public MenuItem getItem() { return item; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { if (quantity < 1) throw new IllegalArgumentException("Quantity must be at least one."); this.quantity = quantity; }
    public double getAmount() { return item.calculatePrice(quantity); }
}

class CanteenException extends Exception {
    public CanteenException(String message) { super(message); }
}

class OrderReceipt {
    private final String orderId;
    private final String customer;
    private final List<OrderItem> items;
    private final double total;
    OrderReceipt(String orderId, String customer, List<OrderItem> items, double total) {
        this.orderId = orderId; this.customer = customer; this.items = items; this.total = total;
    }
    String toJson() {
        StringBuilder lines = new StringBuilder();
        for (OrderItem orderItem : items) {
            if (lines.length() > 0) lines.append(",");
            lines.append("{\"name\":\"").append(escape(orderItem.getItem().getName())).append("\",\"quantity\":")
                 .append(orderItem.getQuantity()).append(",\"amount\":").append(String.format(Locale.US, "%.2f", orderItem.getAmount())).append("}");
        }
        return "{\"orderId\":\"" + orderId + "\",\"customer\":\"" + escape(customer) + "\",\"items\":[" + lines + "],\"total\":" + String.format(Locale.US, "%.2f", total) + "}";
    }
    String toText() {
        StringBuilder text = new StringBuilder("BITEBOX CAMPUS CANTEEN\nOrder: " + orderId + "\nCustomer: " + customer + "\n\n");
        for (OrderItem item : items) text.append(item.getItem().getName()).append(" x ").append(item.getQuantity()).append(" = Rs. ").append(String.format(Locale.US, "%.2f", item.getAmount())).append("\n");
        return text.append("\nTOTAL: Rs. ").append(String.format(Locale.US, "%.2f", total)).append("\nThank you!\n").toString();
    }
    private String escape(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " "); }
}

class CanteenService {
    private final MenuItem[] menu = {
        new FoodItem(1, "Classic Veg Burger", 89, "Burgers"),
        new FoodItem(2, "Crispy Paneer Wrap", 119, "Wraps"),
        new FoodItem(3, "Margherita Pizza", 149, "Pizza"),
        new FoodItem(4, "Masala Fries", 69, "Sides"),
        new FoodItem(5, "Cheese Sandwich", 99, "Sandwiches"),
        new FoodItem(6, "Veg Hakka Noodles", 129, "Bowls"),
        new DrinkItem(7, "Cold Coffee", 79, "Drinks"),
        new DrinkItem(8, "Fresh Lime Soda", 49, "Drinks"),
        new DrinkItem(9, "Iced Lemon Tea", 59, "Drinks"),
        new FoodItem(10, "Chocolate Brownie", 65, "Desserts")
    };

    public MenuItem[] getMenu() { return Arrays.copyOf(menu, menu.length); }
    public String menuAsJson() {
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < menu.length; i++) {
            MenuItem item = menu[i];
            if (i > 0) json.append(",");
            json.append("{\"id\":").append(item.getId()).append(",\"name\":\"").append(item.getName())
                .append("\",\"price\":").append(String.format(Locale.US, "%.2f", item.getPrice()))
                .append(",\"category\":\"").append(item.getCategory()).append("\",\"type\":\"")
                .append(item instanceof DrinkItem ? "drink" : "food").append("\"}");
        }
        return json.append("]").toString();
    }
    public OrderReceipt placeOrder(String customer, String cart) throws CanteenException {
        if (cart == null || cart.isBlank()) throw new CanteenException("Your cart is empty. Add an item before checkout.");
        List<OrderItem> orderItems = new ArrayList<>();
        double total = 0;
        try {
            for (String entry : cart.split(",")) {
                String[] parts = entry.split(":");
                if (parts.length != 2) throw new NumberFormatException();
                int id = Integer.parseInt(parts[0]);
                int quantity = Integer.parseInt(parts[1]);
                if (quantity < 1 || quantity > 20) throw new CanteenException("Each item quantity must be between 1 and 20.");
                MenuItem found = null;
                for (MenuItem item : menu) if (item.getId() == id) { found = item; break; }
                if (found == null) throw new CanteenException("An item in your cart is no longer available.");
                OrderItem orderItem = new OrderItem(found, quantity);
                orderItems.add(orderItem);
                total += orderItem.getAmount();
            }
        } catch (NumberFormatException e) { throw new CanteenException("The cart details were invalid. Please try again."); }
        String orderId = "BB" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"));
        OrderReceipt receipt = new OrderReceipt(orderId, customer, orderItems, total);
        saveReceipt(receipt);
        return receipt;
    }
    private void saveReceipt(OrderReceipt receipt) throws CanteenException {
        try {
            Path folder = Paths.get("receipts");
            Files.createDirectories(folder);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(folder.resolve("order-" + System.currentTimeMillis() + ".txt").toFile()))) {
                writer.write(receipt.toText());
            }
        } catch (IOException e) { throw new CanteenException("The order could not be saved. Please try again."); }
    }
}
