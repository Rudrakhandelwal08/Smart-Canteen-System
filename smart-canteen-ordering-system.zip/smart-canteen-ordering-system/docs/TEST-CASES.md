# Manual test cases

| # | Action | Expected result |
|---|---|---|
| 1 | Open `http://localhost:8080` after starting `run.bat` | Menu loads with food and drinks. |
| 2 | Search for `coffee` | Cold Coffee is shown. |
| 3 | Select the Drinks category | Only drink items are shown. |
| 4 | Add a burger and a drink | Cart count and subtotal update. |
| 5 | Increase and decrease an item's quantity | Quantity and subtotal update correctly. |
| 6 | Place an order with a name | Confirmation shows order number, items and total. |
| 7 | Inspect the `receipts` folder | A text receipt exists for the successful order. |
| 8 | Click checkout with an empty cart | Checkout button is disabled. |
| 9 | Add an item, then submit normally | Java validates and calculates the order on the server. |

The project is a classroom demo, not a payment system. Do not enter real payment information.
