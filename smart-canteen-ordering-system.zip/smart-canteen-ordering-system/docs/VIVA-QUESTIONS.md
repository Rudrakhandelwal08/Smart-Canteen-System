# Viva preparation

**1. Why did you choose this project?**  
It addresses a familiar campus problem: students can browse a canteen menu and prepare an order without standing in the queue just to decide what to buy.

**2. Where is abstraction used?**  
`MenuItem` is abstract. It contains shared data and declares `calculatePrice`, leaving the implementation to child classes.

**3. Explain inheritance in your project.**  
`FoodItem` and `DrinkItem` extend `MenuItem`, so they reuse its ID, name, price, category, and accessor methods.

**4. What is encapsulation?**  
Fields are private. The class controls access through methods, and setters validate values before changing them.

**5. Where is polymorphism?**  
The menu is stored as `MenuItem[]`, but it contains `FoodItem` and `DrinkItem` objects. Calls through the parent type can use overridden methods.

**6. Why use an abstract class instead of creating only `MenuItem` objects?**  
A generic menu item is not specific enough to order. The abstract class defines shared behaviour while child classes represent actual item types.

**7. How does the frontend communicate with Java?**  
It requests `/api/menu` to get menu data and sends the selected item IDs and quantities to `/api/checkout` when an order is placed.

**8. How are invalid orders handled?**  
The backend checks the cart, item IDs and quantities. Invalid input produces a `CanteenException`, which is returned as an error response.

**9. How is file handling used?**  
`BufferedWriter` writes a text receipt into the `receipts` directory after a successful order.

**10. Is this a real payment system?**  
No. It is a local academic demo; it does not accept payments or connect to a production canteen system.
