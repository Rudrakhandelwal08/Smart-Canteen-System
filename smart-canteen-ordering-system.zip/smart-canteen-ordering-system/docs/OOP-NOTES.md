# OOP concepts demonstrated

| Syllabus concept | Where it appears | How to explain it |
|---|---|---|
| Class and object | `MenuItem`, `FoodItem`, `DrinkItem`, `OrderItem`, `CanteenService` | Classes define a type; objects represent individual menu items and order lines. |
| Encapsulation | Private fields in `MenuItem` and `OrderItem` | Data is kept private and accessed through methods. Setters validate updates. |
| Constructors | `MenuItem` default, parameterized and copy constructors; child constructors | Constructors initialize objects. Overloading allows different ways to create an object. |
| Inheritance | `FoodItem extends MenuItem`; `DrinkItem extends MenuItem` | Shared menu-item data is reused by specialised child classes. |
| Abstraction | Abstract class `MenuItem` | It defines common item details and requires a `calculatePrice` implementation. |
| Method overriding | `calculatePrice` in `FoodItem` and `DrinkItem` | Child classes provide their own implementation of a parent abstract method. |
| Polymorphism | `MenuItem[] menu` stores both food and drink objects | A parent-type reference can refer to different child objects. |
| Array of objects | `MenuItem[] menu` | The menu is held in an array of objects. |
| Exception handling | `CanteenException`, `try/catch` in checkout | Invalid cart details are reported without crashing the request handler. |
| Java I/O | `BufferedWriter`, `FileWriter`, `Files` | Successful orders are written to receipt text files. |
| Packages | `package com.smartcanteen;` | Organizes the Java application under a named package. |
